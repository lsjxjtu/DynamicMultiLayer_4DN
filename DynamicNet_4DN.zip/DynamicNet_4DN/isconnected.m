function flag_conn = isconnected(A)

  T = size(A,3);
  for t = 1:T
      At_temp = ( A(:,:,t) > 1e-8 ) + 0;  At_temp = At_temp - diag(diag(At_temp)); At_temp = 0.5*(At_temp + At_temp.'); 
      Gt_unweight = graph(At_temp); 
      DistM = distances(Gt_unweight);
      if sum(sum((isinf(DistM)))) < 0.1
          flag_conn(t) = 1;
      else
          flag_conn(t) = 0;
      end
  end
end