function [Xstr, Xfunc_allRep, Xstrfunc, Xstrfunc_allRep] = FeatureSelection(HiC,Rna,Rna_rep,optionsF)

   Xstr = []; Xstrfunc = [];  Xfunc_allRep = []; Xstrfunc_allRep = [];
   T =  size(HiC,3);
   %%% structure only
   for t = 1:T 
       Xstr_tmp = FeatureSelHiC_modify_dist(HiC(:,:,t),optionsF);
       Xstr(:,:,t) = Xstr_tmp; %%  
       disp(sprintf('Feature Selection at time = %d',t));
   end
   if ~isempty(Rna)
       %%% function only
       T = size(Rna,2);
       if ~isempty(Rna_rep)
           for t = 1:T 
               Xfunc_allRep(:,:,t) = Rna_rep(:,(3*(t-1)+1):(3*t) );
           end
       end

       %%% structure & func 
       T =  size(HiC,3);
       for t = 1:T 
           Xstrfunc(:,:,t) = [Rna(:,t),Xstr(:,:,t)];
           if ~isempty(Rna_rep)
              Xstrfunc_allRep(:,:,t) = [Xfunc_allRep(:,:,t),Xstr(:,:,t)];
           end
       end
   end
   
   
 
end