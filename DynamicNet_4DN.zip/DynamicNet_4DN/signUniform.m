function X = signUniform(X0,alpha)
    %%% X0 \in R^{m \times F}
    
    %%% goal each column has some sign property
    X = X0;
    for i = 1:size(X0,2)
        if sum( sign(X0(1:fix(alpha*size(X0,1)),i)) > 0 ) < sum( sign(X0(1:fix(alpha*size(X0,1)),i)) < 0 )
           X(:,i) = - X(:,i);
        end
    end
end