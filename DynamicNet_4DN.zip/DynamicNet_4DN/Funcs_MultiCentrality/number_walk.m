function [X]=number_walk(A,h)

if(h==1)
    X=sum(A,2);
else
   d=sum(A,2);
   X=[d];
    for i=2:h
        d=A*d;
        X=[X d];
    end
end