function LFVC = LocFiedlerVecCentrality(A)
    n = length(A);
    A = A - diag(diag(A)); A = 0.5*(A + A.'); %% weighted 
    %L = diag(sum(A,2)) - A;  
    [dummy, L] = normalization_A(A);
    eps = 1e0;
    if length(L) > 20
        [Eig2cols Deig] = eigs(sparse(L+eps*eye(size(A,1))), min(20,length(L)), 'SM');
    else
        [Eig2cols Deig] = eig((L+eps*eye(size(A,1))));
    end
    if norm(A - ones(n,n)+diag(ones(n,1)),'fro') < 1e-5
%         LFVC = ones(n,1);
        Leigvec = ones(n,1);
    else
        diag_temp = diag(Deig);
        [~,idx_sort] = sort(diag_temp,'ascend');
        idx_sel = idx_sort(diag_temp(idx_sort)> ( eps + 1e-4) );
        idx_2nd = idx_sel(1);
%         idx_2nd = find(diag(Deig)> ( eps + 1e-4) );
        if ~isempty(idx_2nd)
            if Eig2cols(1,idx_2nd) < 0
                Leigvec = -Eig2cols(:,idx_2nd);
            else
                Leigvec = Eig2cols(:,idx_2nd);
            end
    %         Leigvec = Eig2cols(:,idx_2nd)/sign(Eig2cols(1,idx_2nd));
        else
            error('Error in LFVC for poorly dis-connected graph');
        end
      
    end
     Temp=dist2(Leigvec,Leigvec).*double(A > 1e-10);  Temp = A.*Temp;
     LFVC=sum(Temp,2);
end