function [X]=sum_walk(W,A,h)
X = [];
if(h==1)
   X=sum(W.*A,2);
else
   d=sum(A,2);
   w=sum(W.*A,2);
%    X=[w]; %%% h > 2
   for i=2:h
       w=A*w+W*d;
       X=[X w];
       d=A*d;
   end
end