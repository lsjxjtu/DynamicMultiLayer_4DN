function plot_featureT(F,Name,flag_norm, flag_color)
    figure; n = size(F,1); T = size(F,2);
    co = [0 0 1;
          0 0.5 0;
          1 0 0;
          0 0.75 0.75;
          0.75 0 0.75;
          0.75 0.75 0;
          0.25 0.25 0.25;
          0.5 0.2 0];
    if flag_norm == 1
        Fnorm =  (F - repmat(mean(F,2),1,T)) ./ repmat(std(F,0,2),1,T);
    else
        Fnorm = F;
    end
    for g = 1:n
        if flag_color ==1
            plot(1:T,Fnorm(g,:),'Color',co(g,:)); hold on;
        else
            plot(1:T,Fnorm(g,:),'b'); hold on;
        end
    end
    title(sprintf('%s',Name));
    if flag_color == 1
        legend('Time = 1', 'Time = 2', 'Time = 3', 'Time = 4', 'Time = 5', 'Time = 6', 'Time = 7', 'Time = 8');
    end
end