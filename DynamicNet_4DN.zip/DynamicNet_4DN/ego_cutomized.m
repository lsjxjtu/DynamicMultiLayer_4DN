function ego=ego_cutomized(A)
K=size(A,1);
for i=1:K
    neighbor=(find(A(i,:) > 1e-5)); 
    tmp=union(i,neighbor); tmp=tmp'; u=length(tmp); J=ones(u,u);
    Asub=A(tmp,tmp');
    dummy=triu(ones(u,u),1).*(Asub^2.*(J-Asub));
    ego(i)=(sum(1./dummy(find(dummy>0))));
end

ego=ego';