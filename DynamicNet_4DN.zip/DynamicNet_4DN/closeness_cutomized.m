function [c]=closeness_cutomized(A)

D=graphallshortestpaths(sparse(A));
tmp=sum(D);
tmp(find(tmp==0))=1e-3;

c=(1./tmp)';
