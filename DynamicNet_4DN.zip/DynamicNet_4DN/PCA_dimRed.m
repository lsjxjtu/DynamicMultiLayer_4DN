function [X_red, Q_subspace, tot_var ]= PCA_dimRed(X,q, flag_pre)
        
    %%% sample covariance matrix: X: n \times p: observation \times
    %%% variables
%     n = size(X,1); p = size(X,2);
    
    if flag_pre > 0
%         X = X./( ones(size(X,1),1) * sqrt(sum(X.*X,1)) );
%         X =  (X - repmat(mean(X,1),size(X,1),1)) ./ repmat(std(X,0,1),size(X,1),1);
        X =  (X - repmat(mean(X,1),size(X,1),1)); %%% mean correction
    end
    
    S = cov(X); %%% sample covariance matrix: symmetric; p \times p %%% key
    [U,D,ignore] = svd(S);
    [lam_sort, idx_sort ]= sort(diag(D),'descend');
    U_sort = U(:,idx_sort); 
    tot_var = cumsum(lam_sort)/sum(lam_sort); 
    
    if q < 1
       idx_q = find(tot_var >= q);
       Q_subspace = U_sort(:,1:idx_q(1));
    else
       Q_subspace = U_sort(:,1:q); %%% positive/negative sign of each column of U_sort does not matter
                                %%% Q_coli & -Q_coli is interchangable
    end
    
   Q_subspace = signUniform(Q_subspace,0.1);

   X_red = X*Q_subspace;    %%% X_red_coli = X Q_coli; or  X_red_coli = -X Q_coli; mean(X_red_coli) = +/- mean(-X Q_coli)
    
% %     mu_temp = mean(X_red,1);
% %     idx_temp = find(mu_temp < 0);
   
% %     if ~isempty(idx_temp)
% %         M_temp = ones(size(X_red,1),size(X_red,2));
% %         M_temp2 = ones(size(Q_subspace,1),size(Q_subspace,2));
% %         M_temp(:,idx_temp) = - M_temp(:,idx_temp);
% %         M_temp2(:,idx_temp) = - M_temp2(:,idx_temp);
% %         X_red = X_red.*M_temp;
% %         Q_subspace = Q_subspace.*M_temp2;
% %     end
end