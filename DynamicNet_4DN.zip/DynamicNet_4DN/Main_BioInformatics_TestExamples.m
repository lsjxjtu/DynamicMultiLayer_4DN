%%%% Author: Sijia Liu
%%%% Email: lsjxjtu@umich.edu
%%%% Date: 02/20/2018

%%%% The following script includes a) graph entropy, b) network centrality,
%%%% c) multilayer network theory
%%%% To test the main algorithms, we consider a 
clc; clear all; close all;

addpath('Funcs_MultiCentrality');addpath('graphs_routines');
% Folder_Data = sprintf('CellTrans_Data');  %%%   data file name
% load(fullfile(Folder_Data, 'GeneTADinfo.mat')); %%% gene info.
% load(fullfile(Folder_Data, 'MyoD_gene_Rna_raw.mat')); %%% RNAseq
% chr = 14;
% load(fullfile(Folder_Data, 'MyoD_kb_HiC_rpm.mat'),['C',num2str(chr)]); %% 100 Kb has been correctly ordered
% HiC_100Kb = eval(['C',num2str(chr)]);  
% Tvec = 2:9;
% HiC_100Kb = HiC_100Kb(:,:,Tvec);
% Gene_loc_temp = cell2mat(GeneInfo(:,4));
% Gene_Names =  GeneInfo(find(Gene_loc_temp(:,1)==chr),1);
% RNAseq_raw = FPKM_gene(:,Tvec); %%% ave. rnaseq
% [RNAseq_bin_allT, RNAseq_bin_allT_allRep, list_gene_name_bin ]= Rna2HiCbin_Allchr_modify(RNAseq_raw,[],...
%                                             chr,[1,size(HiC_100Kb,1)+1],GeneInfo,Gene_Names,1e5,'sum'); %%% 100 Kb 1e5
% RNAseq_100Kb =  RNAseq_bin_allT;
% 
% %%% Top normalization
% HiC_100Kb_toep = []; thr = 1e-2;
% for t = 1:size(HiC_100Kb,3)
%     Ht = HiC_100Kb(:,:,t); %%% RPM
%     Ht = 0.5*(Ht + Ht.');
%     Ht_toep = ToepNorm(Ht,1); %normalization_HiC_customize_Kb(Ht,0.99,1);
%     Ht_toep_temp = Ht_toep(Ht_toep>0);
%     thr_cut_max = quantile(Ht_toep_temp(:),1-thr); % quantile(vec(Ht_toep(Ht_toep>0)),1-thr);
%     thr_cut_min = quantile(Ht_toep_temp(:),thr);
%     Ht_toep(Ht_toep>thr_cut_max) = thr_cut_max;
%     Ht_toep(Ht_toep<thr_cut_min) = 0; 
%     HiC_100Kb_toep(:,:,t) = Ht_toep; 
% end
% 
% [idx0_100Kb,idx1_100Kb] = HiC_clean(HiC_100Kb_toep);
% HiC_100Kb = HiC_100Kb_toep(idx1_100Kb,idx1_100Kb,:);
% RNAseq_100Kb =   RNAseq_100Kb(idx1_100Kb,:);
% list_gene_name_bin = list_gene_name_bin(idx1_100Kb,:);
% 
% 
% save(sprintf('TestData_BioInfor_Chr%d.mat',chr),'HiC_100Kb','RNAseq_100Kb','list_gene_name_bin','Gene_Names');

load TestData_BioInfor_Chr14;

%%%% a) Graph entropy
T = size(HiC_100Kb,3);    
GN = [];
GN_approx = [];

for t = 1:T
    
    Ht_toep =  HiC_100Kb(:,:,t);   
    Ht_toep = 0.5*(Ht_toep + Ht_toep.');
    Ht_toep = Ht_toep - diag(diag(Ht_toep)); 
    [~, Lt_norm] = normalization_A(Ht_toep);
    Lt = diag(sum(Ht_toep,2)) - Ht_toep;  
                
    %%% graph entrop, Lap versus normalized Lap
    GN_Lt = graph_entropy(Lt,1); %%% Lap
    [GN_Lt_approx, lb_tmp, ub_tmp ]= graph_entropy_approx(Ht_toep); 
    GN = [GN; GN_Lt];
    GN_approx = [GN_approx; GN_Lt_approx];
    
end %% time points, graph entropy, FN, heterg, FPKM

hfig = figure;
plot(zscore(GN),'LineStyle','--','Color',rgb('darkgrey'),'Marker','o','MarkerEdgeColor','r', 'MarkerFaceColor','r','MarkerSize',6,'LineWidth',1.5); hold on;
plot(zscore(GN_approx),'LineStyle','--','Color',rgb('darkgrey'),'Marker','^','MarkerEdgeColor','g', 'MarkerFaceColor','g','MarkerSize',6,'LineWidth',1.5); hold on;
t_real = [0:8:80];
for t = 1:T
    t_real_str{t} = sprintf('%d',t_real(t));
end
set(gca,'xtick',1:1:T) 
set(gca,'xticklabel',t_real_str,'FontSize', 8,'FontWeight','bold'); 
ylabel('Zscore'); xlabel('Time (hr)');
legend({'Graph entropy', 'GN approx.'});
box off; legend boxoff ;


% b) Centrality + nonlinear PCA
optionsF.feature = {'eig','deg','closeness','clusteringcoeff','h-hop-walk'};  %%% computing 'betweeness' requires 'graph' object in matlab; the old version of MATLAB does not support it
optionsF.nwalk = 5; 
optionsF.unitnorm = 0; optionsF.binaryHiC = 0; optionsF.dist = 0;
[Xstr0, ~, Xstrfunc0, ~] = FeatureSelection(HiC_100Kb,...
                    RNAseq_100Kb,[],optionsF);
                
Xstrfunc = FeatureNorm(Xstrfunc0);   
options_sublearn.knn = 20*T;
low_dim = 2;
X_2D = permute(Xstrfunc,[1 3 2]); 
X_2D = reshape(X_2D,[],size(Xstrfunc,2),1);
[X_2D_red, ~ ] = LapEigMap_customized(X_2D,low_dim,options_sublearn.knn);
N =  size(Xstrfunc,1);
conf_level = 0.98;   
mu_proj = [];  cov_proj = [];  KL = [];
for t = 1:T

    Xtemp = X_2D_red( ( (t-1)*N+1 ):(t*N),:);
    Xnorm = Xtemp./(ones(size(Xtemp,1),1)*sqrt(sum(Xtemp.^2,1)));
    DistPoints = mean(dist2(Xnorm,Xnorm),2);
    cutoff = quantile(DistPoints,conf_level);
    idx_points = find(DistPoints<=cutoff);
    Xtemp_sel = Xtemp(idx_points,:);
    mu_proj(:,t) = mean(Xtemp_sel,1).'; 
    [~,pre_tmp,~ ]= drawEllip(Xtemp_sel,1e-2,1,'k',0);  %%% Minimum vol. ellipsoid
    cov_proj(:,:,t) = inv(pre_tmp);
    if t > 2
        [~,symKL] = KL_distribution(mu_proj(:,t),cov_proj(:,:,t),mu_proj(:,1),cov_proj(:,:,1)); %%% KL compared to initial state, fibroblast 
        KL = [KL; symKL];
    end
end

hfig = figure;
plot((KL),'LineStyle','--','Color',rgb('darkgrey'),'Marker','o','MarkerEdgeColor','r', 'MarkerFaceColor','r','MarkerSize',6,'LineWidth',1.5); hold on;
set(gca,'xtick',1:1:length(KL)) 
set(gca,'xticklabel',t_real_str(3:(length(KL)+1)),'FontSize', 8,'FontWeight','bold'); 
ylabel('KL'); xlabel('Time (hr)');
box off; legend boxoff ;


%%% c) Multilayer network theory
t_real_all = [ 0    8    16    24    32    40    48    56];
Group_t = [0 8 16 24; 32 40 48 56];
deg_alpha_binary = cell(size(Group_t,1),1);
odeg_binary = cell(size(Group_t,1),1); 
p_muli_binary= cell(size(Group_t,1),1); 
eps = 1e-2;
   
    
for i_group = 1:size(Group_t,1)
    t_real = Group_t(i_group,:);
    [~,idx_t_real,~] = intersect(t_real_all,t_real);
            
    Tvec = 1:8; 
    Tvec_MyoD = Tvec(idx_t_real);
    T = length(Tvec_MyoD);
    HiC_multiplex = HiC_100Kb(:,:,Tvec_MyoD);
         
    for alpha = 1:size(HiC_multiplex,3)
        H_alpha = HiC_multiplex(:,:,alpha);
        H_alpha = 0.5*(H_alpha + H_alpha.');
        H_alpha = H_alpha - diag(diag(H_alpha));
        H_alpha_binary = (H_alpha > 1e-1) + 0;
        deg_alpha_binary{i_group}(:,alpha) = sum(H_alpha_binary,2) + eps;
            
    end %%% multilayer
    odeg_binary{i_group} = sum(deg_alpha_binary{i_group},2);
    %%% multiplex coefficient
    temp_data_binary = deg_alpha_binary{i_group}./((odeg_binary{i_group})*ones(1,size(deg_alpha_binary{i_group},2)));
    p_muli_binary{i_group} = (1 - sum(temp_data_binary.^2,2))*T/(T-1);
end
odeg_binary_norm = cell(size(Group_t,1),1); 
p_muli_binary_norm= cell(size(Group_t,1),1); 
for i_group = 1:size(Group_t,1)
     odeg_binary_norm{i_group} = ( odeg_binary{i_group}-min(min(odeg_binary{:})) )./( max(max(odeg_binary{:}))-min(min(odeg_binary{:})) );
     p_muli_binary_norm{i_group} = ( p_muli_binary{i_group}-min(min(p_muli_binary{:})) )./( max(max(p_muli_binary{:}))-min(min(p_muli_binary{:})) );

end

hfig = figure;
plot(p_muli_binary_norm{1},odeg_binary_norm{1} ,'Marker','^', 'MarkerSize',4,'MarkerFaceColor','m','MarkerEdgeColor','m','LineStyle','none'); hold on;
plot(p_muli_binary_norm{2},odeg_binary_norm{2}  ,'Marker','s', 'MarkerSize',4,'MarkerFaceColor','g','MarkerEdgeColor','g','LineStyle','none'); hold on;
hcolor = [];   %
hcolor(1) = plot(NaN,NaN,'Marker','^', 'MarkerSize',8,'MarkerFaceColor','m','MarkerEdgeColor','m','LineStyle','none'); hold on;
hcolor(2) = plot(NaN,NaN,'Marker','s', 'MarkerSize',8,'MarkerFaceColor','g','MarkerEdgeColor','g','LineStyle','none'); hold on;
legend(hcolor,{'0-24 hrs', '32-56 hrs'});  legend('boxoff');
ax = gca;
xlabel('Multiplex participation coeff.');
ylabel('Overlapping degree'); 
