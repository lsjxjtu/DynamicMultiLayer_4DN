function [Xred,Eval] = LapEigMap_customized(X,thr_q,knn)
    %%% X \in m \times F
    m = size(X,1); F = size(X,2);
    sigma2 = 1e3; % 100 determines strength of connection in graph... see below
    %% now let's get pairwise distance info and create graph 
    dt               = squareform(pdist(X));
    [srtdDt,srtdIdx] = sort(dt,'ascend');
    dt               = srtdDt(1:knn+1,:);
    nidx             = srtdIdx(1:knn+1,:);
    
    % compute weights
    tempW  = exp(-dt.^2/sigma2); 
    % build weight matrix
    i = repmat(1:m,knn+1,1);
    W = sparse(i(:),double(nidx(:)),tempW(:),m,m); 
    W = max(W,W'); % for undirected graph.
    
    % The original normalized graph Laplacian, non-corrected for density
    ld = diag(sum(W,2).^(-1/2));
    DO = ld*W*ld; %%% I - DO !!
    DO = (DO + DO.')/2;
    Lap = eye(m) - DO; %% normalized Laplacian
    Lap = 0.5*(Lap + Lap.');
    eps = 1;
    % get eigenvectors
    disp('get eigenvectors in eigmap.....');
%     num_eig = thr_q+1;%min(10,m);
    num_eig = min([m,F,5]);

    [v,d] = eigs(sparse(Lap+eps*eye(m)),num_eig,'sa'); %%% smallest!!
%     [v1,d1] = eigs(sparse(DO+eps*eye(m)),num_eig,'la'); %%% smallest!!
    
    eig_temp = diag(d)-eps;
    [eig_sort, ind_eig_sort] = sort(eig_temp,'ascend');%%% 0 1 2
    idx_nz = find(abs(eig_sort) > 1e-5);
    idx_start = ind_eig_sort(idx_nz(1));
    Xred = v(:,ind_eig_sort(idx_start:(thr_q+idx_start-1)));
    Xred = signUniform(Xred,0.1);
     
%     eig_single = eig(Lap);   
%     idx_nz = find(abs(eig_single) > 1e-5);
%     eig_single_nz = eig_single( idx_nz );
    
     [lam_sort, idx_sort ]= sort(abs(2-eig_sort(idx_nz)),'descend');
    
%     Eval = eig_sort(2:num_eig);
     Eval = cumsum(lam_sort)/sum(lam_sort); 
%     Xred = Xred.*(ones(m,1)*sqrt(eig_sort(2:(thr_q+1))'));
    % 
   
    
end