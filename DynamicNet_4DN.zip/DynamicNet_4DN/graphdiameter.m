function h_diameter = graphdiameter(A)

  h_diameter_vec = []; T = size(A,3);
  for t = 1:T
      At_temp = ( A(:,:,t) > 1e-10 ) + 0;  At_temp = At_temp - diag(diag(At_temp)); At_temp = 0.5*(At_temp + At_temp.'); 
      Gt_unweight = graph(At_temp); 
      DistM = distances(Gt_unweight);
      if sum(sum(isinf(DistM))) > 1e-1
          error('Disconnected graph exists');
      end
      h_diameter_vec =  [ h_diameter_vec,max(DistM(~isinf(DistM))) ];
  end
  h_diameter = max(h_diameter_vec(~isinf(h_diameter_vec)));
end