function [eigcent] = EigCent(A)
    A = A - diag(diag(A)); A = 0.5*(A + A.');
    eps = 1e0;
    [eigcent ignore] = eigs(sparse(A+eps*eye(size(A,1))), 1, 'LA');
    
    
end