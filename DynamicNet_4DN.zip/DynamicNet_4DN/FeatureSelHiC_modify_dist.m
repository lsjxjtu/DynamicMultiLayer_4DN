function Xstr = FeatureSelHiC_modify_dist(Ht,options)
    
    Xstr = []; NumNodes = size(Ht,1);
    Ht = Ht - diag(diag(Ht)); Ht = 0.5*(Ht + Ht.');
    At = ( Ht > 1e-15 ) + 0;
    if options.binaryHiC == 1
        Ht = At;
    end
    Ht_root = nthroot(Ht,2);  
    Ct = 1./Ht_root; 
    Ct(isnan(Ct)) = 0;  Ct(isinf(Ct)) = 0; 

    
    for i_feature = 1:length(options.feature)
         
        switch options.feature{i_feature} %% {'FV','eig','deg','LFVC','h-hop-walk','dist2refs'}
            
            case 'FV'
                %% Fiedler vector: sign info.
                [FN,FV] = Fiedlervec(Ht); %%% weighted
                if FN < 1e-5
                    error('Dis-connected graph!')
                end
                if sum( sign(FV(1:fix(0.1*length(FV)))) > 0 ) < sum( sign(FV(1:fix(0.1*length(FV)))) < 0 )
                     FV = - FV;
                end
                if options.unitnorm
                    FV = FV/norm(FV,2);
                end
                Xstr = [Xstr,vec(FV)];
            case 'eig'
                 %%%% eig-centrality, larger
                 eigc = EigCent(Ht); 
                 if options.unitnorm
                     eigc = eigc/norm(eigc,2);
                 end
                 if ~isempty(find(eigc < -1e-8))
                    eigc = -eigc;
                    if ~isempty(find(eigc <  -1e-8))
                        error('neg-entry in eig. centrality!');
                    end
                 end
                 eigc = abs(eigc);
                 
                 if norm(Ht - ones(NumNodes,NumNodes) + diag(ones(NumNodes,1)),'fro') < 1e-5
                     eigc = ones(NumNodes,1)/norm(ones(NumNodes,1));
                 end
                 
                 Xstr = [Xstr, vec(eigc)]; %%% larger better
            case 'LFVC'
                 %%% LFVC, nonnegative, larger, weighted matrix
                 LFVC  = LocFiedlerVecCentrality(Ht);
                 if options.unitnorm
                    if norm(LFVC) > 0
                        LFVC = LFVC/norm(LFVC);
                    end
                 end
                 if sum(isnan(LFVC))
                    disp('NaN in LFVC!');
                 else
                      Xstr = [Xstr, vec(LFVC)];
                 end  %%% larger unstability, larger impact on connectivity (unweighted), larger group identification (unstable)
            case 'deg'
                 %%% deg,larger more important
                 deg = sum(Ht,2);
                 if options.unitnorm
                    deg = deg/norm(deg);
                 end
                 Xstr = [Xstr, vec(deg)];
                 %%% larger better
            case 'dist2refs' 
                %%% graph distance to a set of reference nodes
                %%% (unweighted): only for destroying symm
                if ~isempty(options.ref)
%                     [SP] = graphallshortestpaths(sparse(At)); %% Ht
%                     x_SP=SP(:,options.ref); 
                    if options.dist 
                        x_SP = distances(Gt_dist,options.ref).'; 
                    else
                        x_SP = distances(Gt_unweight,options.ref).';%%% unweighted  Gt_unweight
                    end
                end
                if  options.unitnorm
                    x_SP = x_SP./( ones(size(x_SP,1),1) * sqrt(sum(x_SP.*x_SP,1)) );
                end
                Xstr = [Xstr, x_SP]; %%% smaller better
                %%%
            case 'h-hop-walk'

                %%%% weight of walks: larger more frequent
                X_sum_walk=sum_walk(Ht,At,options.nwalk);
%                 X_sum_walk=sum_walk(Ct,At,options.nwalk);
                if options.unitnorm
                   X_sum_walk = X_sum_walk./( ones(size(X_sum_walk,1),1) * sqrt(sum(X_sum_walk.*X_sum_walk,1)) );
                end
                Xstr = [Xstr, X_sum_walk];
                %%% larger better
            case 'clusteringcoeff'

%                 ccfs = clustering_coefficients(sparse(At));
                [C1,C2,ccfs] = clust_coeff(At); % Ht_root
                if options.unitnorm
                    if norm(ccfs) > 0
                       ccfs = ccfs/norm(ccfs);
                    end
                end
                if sum(isnan(ccfs))
                    disp('NaN in ccfs!');
                else
                      Xstr = [Xstr, vec(ccfs)];
                end
                %% larger better
            case 'closeness'
                D = graphallshortestpaths(sparse(At));

%                 if options.dist 
%                     D = distances(Gt_dist); %%% Gt_unweight
%                 else
%                     D = distances(Gt_unweight);
%                 end
                clos =1./sum(D,2); %%% larger better
                if options.unitnorm
                     if norm(clos) > 0
                        clos = clos/norm(clos);
                     end
                end
               
                if sum(isnan(clos))
                    disp('NaN in clos!');
                else
                      Xstr = [Xstr, vec(clos)];
                end
            case 'betweeness'
                    %% creat graph object
                 
                if options.dist 
                    Gt_dist = graph(Ct);
                    bet = centrality(Gt_dist,'betweenness','Cost',Gt_dist.Edges.Weight);
%                      bet = centrality(Gt_unweight,'betweenness','Cost',Gt_unweight.Edges.Weight);
                else
                    Gt_unweight = graph(At); 
                    bet = centrality(Gt_unweight,'betweenness','Cost',Gt_unweight.Edges.Weight);

                end
                %% At %%% complete graph betweenness becomes 0, since no node lies in shortest path
%                 bet = centrality(Gt_unweight,'betweenness','Cost',Gt_unweight.Edges.Weight);
                if options.unitnorm
                    if norm(bet) > 0
                     bet = bet/norm(bet);
                    end
                end
                if sum(isnan(bet))
                    disp('NaN in betw!');
                else
                     Xstr = [Xstr, vec(bet)];
                end
               %% larger better
        end
        
        if sum(sum(isinf(Xstr))) > 0 || sum(sum(isnan(Xstr))) > 0
            error('error in feature selection due to inf/nan!')
        end
    end
    