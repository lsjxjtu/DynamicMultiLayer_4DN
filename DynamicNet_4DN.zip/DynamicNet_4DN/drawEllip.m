function [h,A,C ]= drawEllip(X,tol,conf,plot_col,plot_fig)
    
    %%% X \in N \times F
    %%% remove outliers
    Xnorm = X./(ones(size(X,1),1)*sqrt(sum(X.^2,1)));
    DistPoints = mean(dist2(Xnorm,Xnorm),2);
    cutoff = quantile(DistPoints,conf);
    idx_points = find(DistPoints<=cutoff);
    
    %%% ellipsoid
    Xsel = X(idx_points,:);
    [A , C] = MinVolEllipse(Xsel.', tol);
    if plot_fig
        h = Ellipse_plot(A, C, plot_col,'-');
    else
        h = [];
    end
    
end