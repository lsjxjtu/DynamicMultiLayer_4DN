function y = graph_entropy(A,flag)
         
        y = 0 ;
    
        if flag == 1 %%% unnormalized
            A = A/trace(A); 
            eigA = eig(A);
            for i = 1: length(eigA)
                if eigA(i) > 0 
                   y =  - eigA(i)*log(eigA(i)) + y;
                end
            end
        else
            eigA = eig(A);
            for i = 1: length(eigA)
                if eigA(i) > 0 
                   y =  - eigA(i)/2*log(eigA(i)/2) + y;
                end
            end
        end
        
 
    
    

end