function [y,ylb,yub ]= graph_entropy_approx(A)
         
        S = diag(sum(A,2)); s = diag(S);
        L = S - A;  eigL = eig(L/trace(L)); eigL = sort(eigL,'descend');
        
        c = 1/trace(L);
 
        y = 1-c.^2*( s.'*s + sum(sum(A.^2)) ); 
        
        ylb = -y*log(eigL(1))/(1-eigL(end-1));
        yub = -y*log(eigL(end-1))/(1-eigL(1));   
        y = y*log(size(L,1));
end