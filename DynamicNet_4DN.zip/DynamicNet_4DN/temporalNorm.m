function Xnorm = temporalNorm(X)
    
    %%% data matrix X(N,F,T) or X(N,T)
    sz_X = size(X);
    
    if length(sz_X) < 3
       Xnorm =  (X - repmat(mean(X,2),1,size(X,2))) ./ repmat(std(X,0,2),1,size(X,2));
       Xnorm(isnan(Xnorm)) = 0;
    else
        for i = 1:sz_X(2)
            Xi = squeeze(X(:,i,:));
            Xinorm =   (Xi - repmat(mean(Xi,2),1,size(Xi,2))) ./ repmat(std(Xi,0,2),1,size(Xi,2));
            Xinorm(isnan(Xinorm)) = 0;
            Xnorm(:,i,:) = Xinorm;
        end
    end
   
    
end